package com.cryptorecoveryai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.math.BigInteger
import java.math.BigDecimal
import java.math.RoundingMode

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CryptoRecoveryApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CryptoRecoveryApp() {
    var chain by remember { mutableStateOf("Bitcoin") }
    var address by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("آدرس عمومی کیف پول را وارد کنید. عبارت بازیابی یا کلید خصوصی وارد نکنید.") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val chains = listOf("Bitcoin", "Ethereum", "BNB Chain", "Tron")

    MaterialTheme(colorScheme = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF64D8CB),
        secondary = androidx.compose.ui.graphics.Color(0xFFFFC857),
        background = androidx.compose.ui.graphics.Color(0xFF101820),
        surface = androidx.compose.ui.graphics.Color(0xFF182630)
    )) {
        Scaffold(topBar = {
            TopAppBar(title = {
                Column {
                    Text("Crypto Recovery AI", fontWeight = FontWeight.Bold)
                    Text("تحلیل‌گر عمومی بلاکچین", style = MaterialTheme.typography.labelSmall)
                }
            })
        }) { padding ->
            Column(
                Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("مرکز تحلیل کیف پول", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("بررسی فقط با آدرس عمومی؛ بدون دسترسی به دارایی یا اطلاعات محرمانه.")
                    }
                }
                Text("انتخاب شبکه", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    chains.forEach { item ->
                        FilterChip(selected = chain == item, onClick = {
                            chain = item
                            result = "شبکه $item انتخاب شد. آدرس عمومی را وارد کنید."
                        }, label = { Text(item) })
                    }
                }
                OutlinedTextField(
                    value = address, onValueChange = { address = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("آدرس عمومی کیف پول") },
                    placeholder = { Text("Public wallet address") }, singleLine = true
                )
                Button(onClick = {
                    scope.launch {
                        busy = true
                        result = lookup(chain, address.trim())
                        busy = false
                    }
                }, enabled = !busy && address.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                    Text(if (busy) "در حال بررسی..." else "بررسی اطلاعات عمومی")
                }
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("گزارش تحلیل", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(result)
                    }
                }
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("ابزارهای بازیابی مجاز", fontWeight = FontWeight.Bold)
                        Text("• راهنمای بازیابی با نسخه پشتیبان متعلق به مالک")
                        Text("• بررسی شبکه و آدرس عمومی")
                        Text("• تشخیص خطاهای رایج انتقال و انتخاب شبکه")
                        Text("• ثبت گزارش برای پیگیری توسط مالک")
                    }
                }
                Text(
                    "هشدار امنیتی: این برنامه کلید خصوصی یا عبارت بازیابی را جمع‌آوری نمی‌کند. فقط آدرس‌هایی را بررسی کنید که اجازه تحلیل آن‌ها را دارید.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}

private suspend fun lookup(chain: String, address: String): String = withContext(Dispatchers.IO) {
    if (!validAddress(chain, address))
        return@withContext "قالب آدرس برای شبکه انتخاب‌شده معتبر به نظر نمی‌رسد. شبکه و آدرس را دوباره بررسی کنید."
    try {
        when (chain) {
            "Bitcoin" -> {
                val json = get("https://blockstream.info/api/address/$address")
                val funded = Regex("\"funded_txo_sum\":(\\d+)").findAll(json)
                    .mapNotNull { it.groupValues[1].toLongOrNull() }.sum()
                val spent = Regex("\"spent_txo_sum\":(\\d+)").findAll(json)
                    .mapNotNull { it.groupValues[1].toLongOrNull() }.sum()
                val txs = Regex("\"tx_count\":(\\d+)").find(json)?.groupValues?.get(1) ?: "نامشخص"
                "شبکه: Bitcoin\nآدرس: $address\nمجموع ورودی ثبت‌شده: $funded ساتوشی\nمجموع خروجی ثبت‌شده: $spent ساتوشی\nتعداد تراکنش‌ها: $txs\n\nاطلاعات عمومی است و مالکیت یا امکان خرج‌کردن را اثبات نمی‌کند."
            }
            "Ethereum", "BNB Chain" -> {
                val rpc = if (chain == "Ethereum") "https://ethereum-rpc.publicnode.com" else "https://bsc-rpc.publicnode.com"
                val payload = """{"jsonrpc":"2.0","method":"eth_getBalance","params":["$address","latest"],"id":1}"""
                val json = post(rpc, payload)
                val hex = Regex("\"result\"\\s*:\\s*\"(0x[0-9a-fA-F]+)\"").find(json)?.groupValues?.get(1)
                val wei = hex?.removePrefix("0x")?.takeIf { it.isNotBlank() }?.let {
                    runCatching { BigInteger(it, 16) }.getOrNull()
                }
                val native = wei?.let {
                    BigDecimal(it).divide(BigDecimal("1000000000000000000"), 8, RoundingMode.DOWN).toPlainString()
                } ?: "دریافت نشد"
                "شبکه: $chain\nآدرس: $address\nموجودی کوین بومی: $native\n\nتاریخچه کامل و توکن‌ها در نسخه بعدی اضافه می‌شوند. موجودی عمومی مالکیت را اثبات نمی‌کند."
            }
            else -> "قالب آدرس Tron بررسی شد. اتصال به سرویس عمومی Tron در مرحله بعد اضافه می‌شود؛ برای جلوگیری از نمایش اطلاعات ساختگی، موجودی گزارش نشده است."
        }
    } catch (e: Exception) {
        "اتصال به سرویس عمومی ناموفق بود یا محدودیت موقت وجود دارد. بعداً دوباره تلاش کنید. نوع خطا: ${e.javaClass.simpleName}"
    }
}

private fun validAddress(chain: String, a: String): Boolean = when (chain) {
    "Bitcoin" -> (a.startsWith("1") || a.startsWith("3") || a.startsWith("bc1")) && a.length in 26..90
    "Ethereum", "BNB Chain" -> a.matches(Regex("^0x[a-fA-F0-9]{40}$"))
    "Tron" -> a.matches(Regex("^T[1-9A-HJ-NP-Za-km-z]{33}$"))
    else -> false
}

private fun get(url: String): String = (URL(url).openConnection() as HttpURLConnection).run {
    requestMethod = "GET"; connectTimeout = 12000; readTimeout = 12000
    try { inputStream.bufferedReader().use { it.readText() } } finally { disconnect() }
}

private fun post(url: String, body: String): String = (URL(url).openConnection() as HttpURLConnection).run {
    requestMethod = "POST"; doOutput = true
    connectTimeout = 12000; readTimeout = 12000
    setRequestProperty("Content-Type", "application/json")
    try {
        outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        inputStream.bufferedReader().use { it.readText() }
    } finally { disconnect() }
}
